#!/bin/bash
cd frontend
npm start
