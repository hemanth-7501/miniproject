import React, {useState} from "react";
import { motion } from "framer-motion";
import Hero from "./components/Hero";
import UploadPanel from "./components/UploadPanel";
import WebcamPanel from "./components/WebcamPanel";
import VisualizationPanel from "./components/VisualizationPanel";

export default function App(){
  const [lastResult, setLastResult] = useState(null);

  return (
    <div>
      <Hero />
      <motion.main initial={{opacity:0}} animate={{opacity:1}} transition={{duration:0.8}}>
        <div className="container">
          <UploadPanel onResult={setLastResult} />
          <WebcamPanel onResult={setLastResult} />
          <VisualizationPanel lastResult={lastResult} />
        </div>
      </motion.main>
      <footer className="footer">Built with ❤️ · Visual Neural Network — Polished UI</footer>
    </div>
  );
}
