import React from "react";
import { Bar, Pie } from "react-chartjs-2";
import { Chart as ChartJS, ArcElement, CategoryScale, LinearScale, BarElement, Tooltip, Legend } from "chart.js";
ChartJS.register(ArcElement, CategoryScale, LinearScale, BarElement, Tooltip, Legend);

const EMOTIONS = ['Angry','Disgust','Fear','Happy','Sad','Surprise','Neutral'];

export default function VisualizationPanel({lastResult}){
  const labels = EMOTIONS;
  const scores = (lastResult && lastResult.scores) ? lastResult.scores.map(s=>Math.max(0,Math.min(1,s))) : [0.1,0.05,0.1,0.7,0.12,0.05,0.4];

  const barData = {
    labels,
    datasets: [{ label: "Intensity", data: scores, borderWidth:1, backgroundColor: ['#ef4444','#f97316','#f59e0b','#10b981','#60a5fa','#a78bfa','#94a3b8'] }]
  };
  const pieData = { labels, datasets: [{ data: scores, backgroundColor: ['#ef4444','#f97316','#f59e0b','#10b981','#60a5fa','#a78bfa','#94a3b8'] }] };

  return (
    <div className="card">
      <h2>Visualization & Analytics</h2>
      <div className="grid-2" style={{alignItems:"start"}}>
        <div>
          <Bar data={barData} options={{responsive:true, animations:{duration:600}, scales:{y:{min:0,max:1}}}} />
        </div>
        <div style={{width:360}}>
          <Pie data={pieData} />
          <div style={{marginTop:10}} className="small">Charts reflect the most recent prediction. Use them for quick visual analysis or to export results to BI tools.</div>
        </div>
      </div>
    </div>
  )
}
