import React, { useState } from "react";
import { motion } from "framer-motion";
import { FaCloudUploadAlt } from "react-icons/fa";

const API_URL = process.env.REACT_APP_API_URL || "http://localhost:5000/api/predict";
const EMOTIONS = ['Angry','Disgust','Fear','Happy','Sad','Surprise','Neutral'];

function Bars({scores}){
  if(!scores) return null;
  return (
    <div>
      {EMOTIONS.map((label, idx)=>{
        const raw = Number(scores[idx] ?? 0);
        const norm = Math.max(0, Math.min(1, raw));
        return (
          <div className="bar-row" key={label}>
            <div className="label">{label}</div>
            <div className="bar"><div className="fill" style={{width:`${norm*100}%`}}/></div>
            <div className="val">{raw.toFixed(2)}</div>
          </div>
        )
      })}
    </div>
  )
}

export default function UploadPanel({onResult}){
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [result, setResult] = useState(null);

  const onFileChange = (e)=>{
    setFile(e.target.files[0]);
    setPreview(URL.createObjectURL(e.target.files[0]));
    setResult(null);
    setError(null);
  }

  const upload = async ()=>{
    if(!file) return setError("Please choose an image first");
    setLoading(true); setError(null);
    const fd = new FormData();
    fd.append("image", file, file.name);
    try{
      const res = await fetch(API_URL, {method:"POST", body:fd});
      if(!res.ok) throw new Error("Server error");
      const data = await res.json();
      const first = (data.results && data.results[0]) || null;
      setResult(first);
      onResult && onResult(first);
    }catch(err){
      setError(err.message);
    }finally{ setLoading(false); }
  }

  return (
    <motion.div className="card" whileHover={{y:-6}} transition={{type:"spring",stiffness:200}}>
      <h2>Upload Image</h2>
      <div className="row">
        <div style={{flex:1}}>
          <div style={{display:"flex",gap:8,alignItems:"center"}}>
            <label className="btn" style={{display:"inline-flex",gap:8,alignItems:"center",cursor:"pointer"}}>
              <FaCloudUploadAlt /> Choose Image
              <input type="file" accept="image/*" onChange={onFileChange} style={{display:"none"}} />
            </label>
            <button className="btn secondary" onClick={upload} disabled={loading}>{loading? "Predicting..." : "Upload & Predict"}</button>
          </div>
          {error && <div className="error">{error}</div>}
          <div style={{marginTop:12}} className="small">Supported: JPG, PNG. Image is sent to backend for face detection and intensity scoring.</div>
        </div>
        <div>
          {preview ? <img src={preview} className="preview" alt="preview"/> : <div className="small">Image preview will appear here</div>}
        </div>
      </div>

      {result && (
        <motion.div initial={{opacity:0, y:8}} animate={{opacity:1,y:0}} transition={{duration:0.5}} style={{marginTop:14}}>
          <h3>Top: {result.top.emotion} ({result.top.score.toFixed(2)})</h3>
          <Bars scores={result.scores} />
        </motion.div>
      )}
    </motion.div>
  )
}
