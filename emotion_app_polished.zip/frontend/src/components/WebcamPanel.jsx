import React, { useRef, useEffect, useState } from "react";
import { FaCircle } from "react-icons/fa";

const API_URL = process.env.REACT_APP_API_URL || "http://localhost:5000/api/predict";

export default function WebcamPanel({onResult}){
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const overlayRef = useRef(null);
  const [streaming, setStreaming] = useState(false);
  const [intervalId, setIntervalId] = useState(null);
  const [status, setStatus] = useState("idle");
  const [faces, setFaces] = useState([]);

  useEffect(()=>{
    return ()=> stopStream();
  },[]);

  const startStream = async ()=>{
    try{
      const stream = await navigator.mediaDevices.getUserMedia({video:{facingMode:"user"}, audio:false});
      videoRef.current.srcObject = stream;
      await videoRef.current.play();
      setStreaming(true); setStatus("running");
      const id = setInterval(captureAndSend, 1100);
      setIntervalId(id);
    }catch(e){
      setStatus("error: "+e.message);
    }
  };

  const stopStream = ()=>{
    if(videoRef.current && videoRef.current.srcObject){
      videoRef.current.srcObject.getTracks().forEach(t=>t.stop());
      videoRef.current.srcObject = null;
    }
    if(intervalId) clearInterval(intervalId);
    setIntervalId(null);
    setStreaming(false);
    setStatus("stopped");
    clearOverlay();
  };

  const clearOverlay = ()=>{
    const c = overlayRef.current;
    if(!c) return;
    const ctx = c.getContext("2d");
    ctx.clearRect(0,0,c.width,c.height);
  };

  const drawOverlay = (detections)=>{
    const v = videoRef.current;
    const c = overlayRef.current;
    if(!v || !c) return;
    c.width = v.videoWidth;
    c.height = v.videoHeight;
    const ctx = c.getContext("2d");
    ctx.clearRect(0,0,c.width,c.height);
    ctx.lineWidth = Math.max(2, Math.round(c.width/220));
    ctx.font = `${Math.max(12, Math.round(c.width/40))}px Inter, Arial`;
    for(const d of detections || []){
      if(!d.bbox) continue;
      const [x,y,w,h] = d.bbox;
      ctx.strokeStyle = "rgba(99,102,241,0.95)";
      ctx.fillStyle = "rgba(99,102,241,0.95)";
      ctx.beginPath();
      ctx.rect(x, y, w, h);
      ctx.stroke();
      const txt = `${d.top.emotion} (${d.top.score.toFixed(2)})`;
      ctx.fillStyle = "rgba(15,23,42,0.92)";
      ctx.fillRect(x, y - 26, ctx.measureText(txt).width + 12, 22);
      ctx.fillStyle = "white";
      ctx.fillText(txt, x + 6, y - 10);
    }
  };

  const captureAndSend = async ()=>{
    if(!videoRef.current) return;
    const v = videoRef.current;
    const w = v.videoWidth, h = v.videoHeight;
    if(w===0 || h===0) return;
    const canvas = canvasRef.current;
    canvas.width = w; canvas.height = h;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(v, 0, 0, w, h);
    canvas.toBlob(async (blob)=>{
      const fd = new FormData();
      fd.append("image", blob, "frame.jpg");
      try{
        const res = await fetch(API_URL, {method:"POST", body:fd});
        if(!res.ok) return;
        const data = await res.json();
        const det = data.results || [];
        setFaces(det);
        drawOverlay(det);
        if(det && det.length>0) onResult && onResult(det[0]);
      }catch(e){
        console.error("webcam send err", e);
      }
    },"image/jpeg",0.7);
  };

  return (
    <div className="card">
      <h2>Real-time Webcam (Multi-face Detection)</h2>
      <div style={{display:"flex",gap:12,alignItems:"flex-start",flexWrap:"wrap"}}>
        <div className="webcam-wrap">
          <video ref={videoRef} style={{width:360, borderRadius:10}} autoPlay muted playsInline />
          <canvas ref={overlayRef} className="overlay-canvas" style={{left:0,top:0}}/>
          <canvas ref={canvasRef} style={{display:"none"}}/>
          <div style={{marginTop:8}}>
            {!streaming ? <button className="btn" onClick={startStream}>Start Webcam</button> : <button className="btn secondary" onClick={stopStream}>Stop Webcam</button>}
            <span style={{marginLeft:12}} className="small"><FaCircle style={{color: streaming? "#10b981":"#ef4444", marginRight:6}} />{status}</span>
          </div>
        </div>
        <div style={{flex:1, minWidth:220}}>
          <h4>Detected Faces</h4>
          <div className="face-list">
            {faces.length===0 && <div className="small">No faces detected yet.</div>}
            {faces.map((f, i)=>(
              <div key={i} className="face-pill">{i+1}. {f.top.emotion} ({f.top.score.toFixed(2)})</div>
            ))}
          </div>
          <div style={{marginTop:12}} className="small">Tip: Allow camera access. Frames are sent periodically to the backend for inference.</div>
        </div>
      </div>
    </div>
  )
}
