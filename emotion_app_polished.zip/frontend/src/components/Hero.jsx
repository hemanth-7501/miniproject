import React from "react";
import { motion } from "framer-motion";
import { FaChevronDown } from "react-icons/fa";

export default function Hero(){
  return (
    <section className="hero">
      <div className="hero-inner">
        <motion.h1 initial={{y:10,opacity:0}} animate={{y:0,opacity:1}} transition={{delay:0.1,duration:0.6}}>
          Sentiment Analysis — Visual Neural Network
        </motion.h1>
        <motion.p initial={{y:8,opacity:0}} animate={{y:0,opacity:1}} transition={{delay:0.2,duration:0.6}}>
          Image-based emotion intensity recognition with real-time webcam and multi-face support.
        </motion.p>
      </div>
      <div className="scroll-hint"><FaChevronDown /></div>
    </section>
  )
}
