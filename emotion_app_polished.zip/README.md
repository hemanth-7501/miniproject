# Polished Emotion Recognition App (React + Flask)

This polished version includes animations (framer-motion), responsive design, webcam overlay, and nicer visuals.

## Run backend
cd backend
python -m venv venv
# activate venv
pip install -r requirements.txt
python app.py

## Run frontend
cd frontend
npm install
npm start

Place your model checkpoint at project root: emotion_vnn_model.pt or checkpoints/emotion_intensity_model.pth
