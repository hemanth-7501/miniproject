#!/bin/bash
cd backend
python app.py
